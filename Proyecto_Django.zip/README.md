# Proyecto Django - SENA ADSI 190

Esta es la carpeta con el proyecto realizado en Django Python para la clase de Django de ADSI 190.